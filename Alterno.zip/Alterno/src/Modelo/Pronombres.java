package Modelo;

public class Pronombres {
	public static final String YO = "yo";
	public static final String TU = "tu";
	public static final String EL = "el";
	public static final String ELLA = "ella";
	public static final String ELLOS = "ellos";
	public static final String USTEDES = "ustedes";

}
