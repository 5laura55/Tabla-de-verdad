package Modelo;

public class Proposicion {

	/*
	 * creacion de variables
	 */
	private String sujeto;

	private String verbo;

	private String complemento;
	private String[] partes;

	/*
	 * constructor
	 */
	public Proposicion() {
	}

	/*
	 * Construcror parametrixado
	 */
	public Proposicion(String s, String v, String c) {

		this.sujeto = s;
		this.verbo = v;
		this.complemento = c;
	}

	public void imprimir(String[] l) {
		for (int i = 0; i < l.length; i++) {
			System.out.println(l[i]);
		}
	}

	/*
	 * metodos set y get
	 */
	public String getSujeto() {
		return sujeto;
	}

	public void setSujeto(String sujeto) {
		this.sujeto = sujeto;
	}

	public String getVerbo() {
		return verbo;
	}

	public void setVerbo(String verbo) {
		this.verbo = verbo;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

}
