package Modelo;

public class Operadores {

	private String and;

	private String or;

	private String entonces;

	private String not;

	public Operadores() {
	}

	public String getAnd() {
		return and = "and";
	}

	public void setAnd(String and) {
		this.and = and;
	}

	public String getOr() {
		return or = "or";
	}

	public void setOr(String or) {
		this.or = or;
	}

	public String getEntonces() {
		return entonces = "enton";
	}

	public void setEntonces(String entonces) {
		this.entonces = entonces;
	}

	public String getNot() {
		return not = "not";
	}

	public void setNot(String not) {
		this.not = not;
	}
}
