package Logica;

import java.util.ArrayList;
import java.util.List;
import Proposiciones.Principal;

import Modelo.Operadores;
import Modelo.Pronombres;
import Modelo.Proposicion;

/**
 *
 * @author Edgar
 */
public class Evaluador {
	private Proposicion proposicion;
	private String resultado;

	private Operadores operadores;

	public Evaluador() {
		operadores = new Operadores();
		proposicion = new Proposicion();
	}

	public List<String> generarTablas(int numeroPropo) {

		String tmpValor;
		List<String> lista = new ArrayList<>();
		String tabla = null;
		String tabla2 = "";
		int filas;
		int numPrepo = numeroPropo;
		filas = (int) Math.pow(2, numPrepo);
		for (int i = 0; i < filas; i++) {
			tabla = Integer.toBinaryString(i);
			while (tabla.length() < numPrepo) {
				tabla = 0 + tabla;

			}
			tabla = tabla.replace("0", "V");
			tabla = tabla.replace("1", "F");

			lista.add(tabla);

		}
		return lista;

	}

	public boolean sujetoCorrecto1(String sujeto) {

		if (sujeto.equals(Pronombres.EL) || sujeto.equals(Pronombres.ELLA) || sujeto.equals(Pronombres.ELLOS)
				|| sujeto.equals(Pronombres.TU) || sujeto.equals(Pronombres.USTEDES) || sujeto.equals(Pronombres.YO)) {

			return true;
		} else {
			System.out.println("EL SUJETO ESTA INCORRECTO");
			return false;
		}

	}

	public boolean verboCorrecto1(String verbo) {

		char ultimo = verbo.charAt(verbo.length() - 1);
		char penultimo = verbo.charAt(verbo.length() - 2);

		if (ultimo == 'r'
				&& (penultimo == 'a' || penultimo == 'e' || penultimo == 'i' || penultimo == 'o' || penultimo == 'u')) {
			return true;
		} else {
			return false;
		}

	}

	// Le entra como parametro lista de 2^n *2 no puede ser la tabla completa
	public List<String> evaluaAnd(List<String> p, String operador) {
		List<String> listaResultado = new ArrayList<>();
		String resul;

		for (int i = 0; i < p.size(); i++) {
			System.out.println("entre al for");
			if (p.get(i).contains("F"))
				listaResultado.add("F");
			else
				listaResultado.add("V");
		}

		return listaResultado;
	}

	public void imprimirLista(List<String> lista) {
		for (int j = 0; j < lista.size(); j++) {

			System.out.println(lista.get(j));
		}
	}

	public List<String> evaluaOr(List<String> p, String operador) {
		List<String> listaResultado = new ArrayList<>();
		String resul;

		for (int i = 0; i < p.size(); i++) {
			if (p.get(i).contains("V"))
				listaResultado.add("V");
			else
				listaResultado.add("F");
		}

		return listaResultado;
	}

	public List<String> evaluaThen(List<String> p, String operador) {
		List<String> listaResultado = new ArrayList<>();
		String resul;

		for (int i = 0; i < p.size(); i++) {
			if (p.get(i).charAt(0) + "" == "V" && p.get(i).charAt(1) + "" == "F")
				listaResultado.add("F");
			else
				listaResultado.add("V");
		}

		return listaResultado;
	}

	// Le entra una lista de 2^n *1
	public List<String> evaluaNot(List<String> p, String operador) {
		List<String> listaResultado = new ArrayList<>();
		String resul;

		for (int i = 0; i < p.size(); i++) {
			if (p.get(i).contains("V"))
				listaResultado.add("F");
			else
				listaResultado.add("V");
		}

		return listaResultado;
	}

	/*
	 * public String[] descomposicionEnPalabras() { int contador = 1;
	 * 
	 * for (int i = 0; i < frase.length(); i++) { if (frase.charAt(i) == ' ') {
	 * contador++; } }
	 * 
	 * palabras = new String[contador]; palabras= frase.split(" ");
	 * imprimir(palabras);
	 * 
	 * return palabras; } public void imprimir(String[] l){ for (int i = 0; i <
	 * l.length; i++) { System.out.println(l[i]); } }
	 */
}
