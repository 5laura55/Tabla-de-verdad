package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelProposiciones extends JPanel implements ActionListener{
private	Interfaz interfaz;
private final String OPCION = "Listo";
private final String OK = "Ok";
private JButton boton;
private JLabel etiquetaNombre ;
private JTextField txtNombre;
private int numeroPropo;
private Subpanel[] subpaneles;

	public PanelProposiciones(Interfaz inte) {
		interfaz=inte;
		 setBorder( new TitledBorder( "Proposiciones" ) );
		 setPreferredSize(new Dimension(960, 200));
		 etiquetaNombre = new JLabel("¿Cuantas proposiciones desea realizar?");
		txtNombre=new JTextField(4);
		
        add(etiquetaNombre);
        add(txtNombre);
		 boton = new JButton( "Listo" );
	        boton.setActionCommand( OPCION );
	        boton.addActionListener( this );
	        add( boton );
			
	}
	public void actualizar() {
		
		interfaz.cerrar();
		remove(boton);
		remove(txtNombre);
		remove(etiquetaNombre); 
		interfaz.setVisible(true);
		
		JButton botonAgregar = new JButton("Agregar");
		botonAgregar.setActionCommand(OK);

		botonAgregar.addActionListener(this);
		botonAgregar.setForeground(Color.black);
	
		
		botonAgregar.setPreferredSize(new Dimension(20, 20));
	
		setLayout(new BorderLayout());
	    add(botonAgregar,BorderLayout.SOUTH);
	    
		JPanel division=new JPanel();
		add(division,BorderLayout.CENTER);
		division.setLayout(new GridLayout(numeroPropo, 3));
		subpaneles= new Subpanel[numeroPropo];
		for (int i = 0; i < numeroPropo; i++) {
			Subpanel temp=new Subpanel(interfaz);
			subpaneles[i]=temp;
			division.add(temp);
			
		}
	
		
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando = e.getActionCommand( );
        if( OPCION.equals( comando ) )
        {
        	String strNombre = txtNombre.getText();
          	numeroPropo=Integer.parseInt(strNombre);
          	interfaz.getMundo().preguntarLargo(numeroPropo);
          	interfaz.getMundo().tabla();
            interfaz.refrescarPanel1();
        }
        else if(OK.equals( comando ) ) {
       
        	for (int i = 0; i < subpaneles.length; i++) {
        		
        		if(interfaz.getMundo().nuevaProposicion(subpaneles[i].getTxtSujeto().getText().toLowerCase(),subpaneles[i].getTxtVerbo().getText().toLowerCase(),subpaneles[i].getTxtCompl().getText())) {
        			if(i==subpaneles.length-1) 
        			JOptionPane.showMessageDialog(this, "Se han creado las proposiciones con exito");
        		   interfaz.activarPanel2();
        		}
        		else {
        			JOptionPane.showMessageDialog(this,"El sujeto y/o verbo de la propisicion"+(i+1)+"esta incorrecto");
        			interfaz.getMundo().eliminarProposiciones();
        			break;
        		
        		}
        		
			}
        
        
        }
		// TODO Auto-generated method stub
		
	}
}
