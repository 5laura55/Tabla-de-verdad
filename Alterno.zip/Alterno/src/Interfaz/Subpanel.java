package Interfaz;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class Subpanel extends JPanel{
	private Interfaz interfaz;
	JTextField txtSujeto;
	JTextField txtVerbo;
	JTextField txtCompl;
public Subpanel(Interfaz inter) {
	interfaz=inter;
	setLayout(new GridLayout(1,6));
	JLabel etiquetaSujeto = new JLabel("Sujeto:");
	add(etiquetaSujeto);

	 txtSujeto = new JTextField(6);
	add(txtSujeto);

	JLabel etiquetaVerbo = new JLabel("Verbo:");
	add(etiquetaVerbo);

	 txtVerbo = new JTextField(6);
	add(txtVerbo);
	JLabel etiquetaCompl = new JLabel("Complemento:");
	add(etiquetaCompl);

	txtCompl = new JTextField(6);
	add(txtCompl);
	
	
	

	
   

}
public JTextField getTxtSujeto() {
	return txtSujeto;
}

public JTextField getTxtVerbo() {
	return txtVerbo;
}

public JTextField getTxtCompl() {
	return txtCompl;
}

}
