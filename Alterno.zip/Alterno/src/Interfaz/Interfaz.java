package Interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.GrayFilter;
import javax.swing.JFrame;
import javax.swing.UIManager;

import Proposiciones.Principal;


public class Interfaz extends JFrame {
	// atributos
	private PanelOperaciones panelOperaciones;
	private PanelProposiciones panelProposiciones;
	private PanelTabla panelTabla;
	private Principal principalMundo;

	public Interfaz() {
		setTitle("CALCULADORA DE TABLAS DE VERDAD");
		setSize(960, 700);
		setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
		principalMundo = new Principal();
		setLayout(new BorderLayout());
		panelProposiciones = new PanelProposiciones(this);
		add(panelProposiciones,BorderLayout.NORTH);
		
		panelOperaciones=new PanelOperaciones(this);
		add(panelOperaciones,BorderLayout.CENTER);
		
		panelTabla=new PanelTabla(this);
		add(panelTabla,BorderLayout.SOUTH);

		setLocationRelativeTo( null );

	}
	public void refrescarPanel1() {
		panelProposiciones.actualizar();
		
	}
	public void refrescarPanel2() {
		panelProposiciones.setEnabled(false);
		panelOperaciones.actualizar();
	}
	public void cerrar() {
		dispose();
	}
	public void darRespuesta()
	{
		panelTabla.actualizar();
	}
	public Principal getMundo() {
		return principalMundo;
	}
	public void activarPanel2(){
		panelOperaciones.activarPanel();
	}

	public static void main(String[] args) {
		 

	            Interfaz interfaz = new Interfaz( );
	            interfaz.setVisible( true );
	     
	    }
	
}
