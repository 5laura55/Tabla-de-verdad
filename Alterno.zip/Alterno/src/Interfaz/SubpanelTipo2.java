package Interfaz;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class SubpanelTipo2 extends JPanel{
	private Interfaz interfaz;
	JTextField txtSujeto;
	JTextField txtVerbo;
	JTextField txtCompl;
    public SubpanelTipo2(Interfaz inter) {
	interfaz=inter;
	setLayout(new GridLayout(3,1));
	JLabel etiquetaSujeto = new JLabel("1ª proposicion:");
	add(etiquetaSujeto);

	 txtSujeto = new JTextField(6);
	add(txtSujeto);

	JLabel etiquetaVerbo = new JLabel("2ª  proposicion:");
	add(etiquetaVerbo);

	 txtVerbo = new JTextField(6);
	add(txtVerbo);
	JLabel etiquetaCompl = new JLabel("Operador(AND,OR,THEN,NOT)");
	etiquetaCompl.setForeground(Color.blue);
	add(etiquetaCompl);

	txtCompl = new JTextField(6);
	add(txtCompl);
	
	

	
   

}
public JTextField getTxtSujeto() {
	return txtSujeto;
}

public JTextField getTxtVerbo() {
	return txtVerbo;
}

public JTextField getTxtCompl() {
	return txtCompl;
}

}
