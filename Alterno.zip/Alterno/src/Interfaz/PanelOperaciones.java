package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelOperaciones extends JPanel implements ActionListener{
	Interfaz interfaz;
	private final String OPCION = "Listo";
	private final String OK = "Ok";
	private JButton boton;
	private JTextField txtNombre;
	private int numeroOperaciones;
	private JLabel etiquetaNombre ;
	private SubpanelTipo2[] subpaneles;
	public PanelOperaciones(Interfaz inte) {
		interfaz=inte;
		 setBorder( new TitledBorder( "Operaciones" ) );
		
		 etiquetaNombre = new JLabel("¿Cuantas operaciones desea realizar?");
		 txtNombre=new JTextField(4);
		txtNombre.setEnabled(false);
        add(etiquetaNombre);
        add(txtNombre);
		 boton = new JButton( "Listo" );
	        boton.setActionCommand( OPCION );
	        boton.addActionListener( this );
	        boton.setEnabled(false);
	        
	        add( boton );
	        
	}
	public void actualizar() {
		interfaz.cerrar();
		remove(txtNombre);
		remove(etiquetaNombre);
		remove(boton);
        interfaz.setVisible(true);
        setLayout(new BorderLayout());
	   
		JButton botonAgregar = new JButton("Enviar datos");
		botonAgregar.setActionCommand(OK);

		botonAgregar.addActionListener(this);
		botonAgregar.setPreferredSize(new Dimension(20, 20));
		botonAgregar.setForeground(Color.black);
		 add(botonAgregar,BorderLayout.SOUTH);
		 JPanel division=new JPanel();
			add(division,BorderLayout.CENTER);
			division.setLayout(new GridLayout(numeroOperaciones, 3));
		
		subpaneles= new SubpanelTipo2[numeroOperaciones];
		for (int i = 0; i < numeroOperaciones; i++) {
			SubpanelTipo2 temp=new SubpanelTipo2(interfaz);
			subpaneles[i]=temp;
			division.add(temp);
			
		}
		
		
		
		
	}
	public void activarPanel() {
		boton.setEnabled(true);
		txtNombre.setEnabled(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando = e.getActionCommand( );
        if( OPCION.equals( comando ) )
        {
        	numeroOperaciones=Integer.parseInt(txtNombre.getText());
        
        	interfaz.refrescarPanel2();
        }
        else if(OK.equals(comando)) {
        	int uno;
        	int dos;
        	String operacion;
         	for (int i = 0; i < subpaneles.length; i++) {
         		uno=Integer.parseInt(subpaneles[i].getTxtSujeto().getText());
         		dos=Integer.parseInt(subpaneles[i].getTxtVerbo().getText());
         		operacion=subpaneles[i].getTxtCompl().getText().toUpperCase();
         		interfaz.getMundo().realizarOperación(uno, dos, operacion);
         		if(i==subpaneles.length-1) {
         			interfaz.darRespuesta();
         		}
         		
         	}
        }
		
	}

}
