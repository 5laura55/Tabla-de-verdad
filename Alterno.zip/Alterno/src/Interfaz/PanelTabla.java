package Interfaz;

import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

public class PanelTabla extends JPanel{
	Interfaz interfaz;
	public PanelTabla(Interfaz inte) {
		interfaz=inte;
		 setBorder( new TitledBorder( "Tabla de verdad" ) );
		 setPreferredSize(new Dimension(960, 235));
	}
	public void actualizar() {
		interfaz.cerrar();
		String title=interfaz.getMundo().getTitulo();
			System.out.println(title);
		String[] ti=title.split("/");
		for (int i = 0; i < ti.length; i++) {
			System.out.println(ti[i]);
		}
	
		System.out.println("el largo es "+interfaz.getMundo().respuesta().length+"ancho"+interfaz.getMundo().respuesta()[0].length);
		JTable matriz=new JTable(interfaz.getMundo().respuesta(),ti);
		matriz.setMaximumSize(new Dimension(250,950));
		JScrollPane sc = new JScrollPane(matriz);
		sc.setBounds(5, 112, 200, 500);
	     add(sc);
		setVisible(true);
		interfaz.setVisible(true);
	}
	
}
