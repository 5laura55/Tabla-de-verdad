package Proposiciones;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Logica.Evaluador;
import Modelo.Proposicion;

/**
 *
 * @author Laura
 */
public class Principal {
	private ArrayList<Proposicion> proposiciones;
	private int largo;
	private int ancho;
	Evaluador evaluador;
	List<String> tabla;
	List<String> tablaFinal;
	List<String> actual;
	String titulo;

	/**
	 * @param args
	 *            the command line arguments
	 */
	public Principal() {
		proposiciones = new ArrayList<Proposicion>();
		evaluador = new Evaluador();
		tabla = new ArrayList<>();
		tablaFinal = new ArrayList<>();
		actual = new ArrayList<>();
		titulo = "";

	}

	public ArrayList<Proposicion> darProposiciones() {
		return proposiciones;
	}

	public Boolean nuevaProposicion(String s, String v, String c) {
		if(evaluador.sujetoCorrecto1(s)&&evaluador.verboCorrecto1(v)) {
		Proposicion p = new Proposicion(s, v, c);
		proposiciones.add(p);
		return true;
		}
		else {
			System.out.println("error en el sujeto");
			return false;
		}
	}
	public void eliminarProposiciones() {
		proposiciones.clear();
		
	}

	public void preguntarLargo(int l) {
		largo = (int) Math.pow(2, l);

		ancho = l;
	}

	public void tabla() {

		tabla = evaluador.generarTablas(ancho);
		System.out.println("La tabla de proposiciones es");
		imprimirLista(tabla);
		tablaFinal.addAll(tabla);
		for (int i = 0; i < ancho; i++) {
			titulo = titulo.concat("P" + (i + 1) + "/");
		}

	}

	public List<String> realizarOperación(int prop1, int prop2, String operacion) {
		ancho++;
		List<String> temporal = new ArrayList<>();
		if (prop1 == -1) {
			temporal = actual;
		}
		titulo = titulo.concat( "P" + prop1 + " " + operacion + " P" + prop2 + "/");
		List<String> respuesta = new ArrayList<>();

		// si es not
		if (operacion.equals("NOT")) {
			// separar la columna de la fila

			for (int i = 0; i < largo; i++) {
				int prop = 0;
				prop = prop2 - 1;
				temporal.add(tabla.get(i).charAt(prop) + "");
			}
			respuesta = evaluador.evaluaNot(temporal, operacion);

			actual = respuesta;
			// pegado
			List<String> tablaTemporal22 = new ArrayList();

			for (int k = 0; k < tablaFinal.size(); k++) {
				tablaTemporal22.add(tablaFinal.get(k).concat(respuesta.get(k)));
			}

			tablaFinal = tablaTemporal22;
			System.out.println(titulo);
			imprimirLista(tablaFinal);
			return respuesta;
		}
		// crear lista de las proposiciones dichas
		List<String> tablaTemporalx = new ArrayList();
		for (int i = 0; i < largo; i++) {
			if (prop1 == -1) {
				tablaTemporalx.add(temporal.get(i).concat(tabla.get(i).charAt(prop2 - 1) + ""));

			} else
				temporal.add((tabla.get(i).charAt(prop1 - 1) + "").concat(tabla.get(i).charAt(prop2 - 1) + ""));
		}
		if (prop1 == -1)
			temporal = tablaTemporalx;

		// si es otra operacion

		if (operacion.equals("AND")) {

			respuesta = evaluador.evaluaAnd(temporal, operacion);
		} else if (operacion.equals("OR")) {
			respuesta = evaluador.evaluaOr(temporal, operacion);
		} else {
			respuesta = evaluador.evaluaThen(temporal, operacion);
		}

		List<String> tablaTemporal = new ArrayList();

		for (int i = 0; i < largo; i++) {
			tablaTemporal.add(tablaFinal.get(i).concat(respuesta.get(i)));
		}

		System.out.println("La tabla final");
		System.out.println(titulo);
		tablaFinal = tablaTemporal;
		imprimirLista(tablaFinal);
		actual.addAll(respuesta);
		return respuesta;

	}

	public void imprimirLista(List<String> lista) {
		for (int j = 0; j < lista.size(); j++) {

			System.out.println(lista.get(j));
		}
	}
//Me ordena la tabla en una matriz
	public String[][] respuesta() {
		
		
    String[][] matriz=new String[largo][ancho];
		for (int j = 0; j < largo; j++) {
 
			for (int i = 0; i < ancho; i++) {
				matriz[j][i]=tablaFinal.get(j).charAt(i)+"";
			}
		}
		return matriz;
	}

	public void metodo() {
		
	}

	public String getTitulo() {
		return titulo;
	}

	public int getAncho() {
		return ancho;
	}
	public int getLargo() {
		return largo;
	}

}
